#main file for QR code generator 
'''(1)_First of all here I installed Flask package By using
"pip install flask", here pip is a python package manager which usually installs 
and upgrades the different packages and dependencies in python
(2)_After that i have installed python qr code generator with 
command "pip install qrcode[pil]"
(3) We are using flask web framework in this project
'''
from flask import Flask,render_template,request
import qrcode
from io import BytesIO
from base64 import b64encode

app = Flask(__name__)
@app.route('/')
def home():
    return render_template('index.html')


@app.route('/', methods=['POST'])
def generateQR():
    memory =BytesIO()
    data = request.form.get('link')
    img=qrcode.make(data)
    img.save(memory)
    memory.seek(0)
    
    base64_img ="data:image/png;base64," + \
       b64encode(memory.getvalue()).decode('ascii')
    
    return render_template('index.html', data=base64_img)

if __name__ == '__main__':
    app.run(debug=True)